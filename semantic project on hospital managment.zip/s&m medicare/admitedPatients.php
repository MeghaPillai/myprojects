<!doctype html>
<?php
include( "functions.php" );
 
$obj =  new Functions();
$patientType = $_GET["patientType"];
$result = $obj->getPaitents($patientType); 
?>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> Hospital management System </title>

    <link rel="shortcut icon" href="assets/images/fav.jpg">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawsom-all.min.css">
     <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
</head>
<body>

<!-- ################# Header Starts Here#######################--->

  <header id="menu-jk">

    <div id="nav-head" class="header-nav">
        <div class="container">
            <div class="row">
                <div class="col-lg-2 col-md-3  col-sm-12" style="color:#000;font-weight:bold; font-size:42px; margin-top: 1% !important;">S&M Medicare
                   <a data-toggle="collapse" data-target="#menu" href="#menu" ><i class="fas d-block d-md-none small-menu fa-bars"></i></a>
                </div>
                <div id="menu" class="col-lg-8 col-md-9 d-none d-md-block nav-item">
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#services">Services</a></li>
                        
                        <li><a href="#contact_us">Contact Us</a></li>
                   
                    </ul>
                </div>
             
            </div>

        </div>
    </div>
</header>


<!-- ################# patient search#######################--->

<section id="logins" class="our-blog container-fluid">
        <div class="container">
        <div class="inner-title">

                <h2 style="color:Tomato;"><b><u><?php echo $patientType ?> Patient</u></b></h2>
            </div>
            
    
    <table class="table table-bordered">
    <tr>
    <th>ID</th>
    <th>NAME</th>
    <th>AGE</th>
    <th>GENDER</th>
    <th>BLOOD GROUP</th>
    <th>ADDRESS</th>

    
  </tr>
 
                <?php
		while( $row = sparql_fetch_array( $result ) )
		{
		?>           <tr>
                    <td class="card-text"><?php echo $row["ID"]; ?></td>
                  <td class="card-text"><?php echo $row["patient_name"]; ?></td>
                  <td class="card-text"><?php echo $row["age"]; ?></td>
                  <td class="card-text"><?php echo $row["gender"]; ?></td>
                  <td class="card-text"><?php echo $row["bg"]; ?></td>
                  <td class="card-text"><?php echo $row["address"]; ?></td>

                  </tr>
            <?php } ?>

         

  <!--<script src="/movies_app/js/holder.min.js"></script>!-->
  </body>
</html>
