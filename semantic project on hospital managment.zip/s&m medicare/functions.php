<?php
require_once( "sparql_library.php" );

class Functions{
    private $db;
    
    public function __construct(){
	$db = sparql_connect( "http://localhost:3030/hospital1/sparql" );
	if( !$db ) { print sparql_errno() . ": ---" . sparql_error(). "\n"; exit; }
	sparql_ns( "hs","http://www.semanticweb.org/megha/ontologies/2022/10/untitled-ontology-44#" );
  sparql_ns( "rdfs","http://www.w3.org/2000/01/rdf-schema#" );
    }

    #TO get patients data depending on the type of patients
    public function getPaitents($patientType){

        #ADMITED PATIENT
        if($patientType=="Admited"){
        $sparql = "SELECT ?patient_name ?ID ?gender ?bg ?age ?address
        WHERE { 
          ?patient a hs:Admited_patients.
          
          ?patient hs:pat_name ?patient_name.
          ?patient hs:pat_id ?ID.
          ?patient hs:pat_gender ?gender.
          ?patient hs:pat_bloodgroup ?bg.

          ?patient hs:pat_age ?age.
          ?patient hs:pat_address ?address


           }";
        $result = sparql_query( $sparql ); 
        
        return $result;
        }

        #DISCHARGE PATIENT
        if($patientType=="Discharged"){
            $sparql = "SELECT ?patient_name  ?gender ?bg ?age ?address ?ID
            WHERE { 
              ?patient a hs:Discharge_Patients.
              ?patient hs:pat_id ?ID.

              ?patient hs:pat_name ?patient_name.
              ?patient hs:pat_gender ?gender.
              ?patient hs:pat_bloodgroup ?bg.
    
              ?patient hs:pat_age ?age.
              ?patient hs:pat_address ?address
    
               }";
            $result = sparql_query( $sparql ); 
            return $result;
            }


            if($patientType=="OP"){
                $sparql = "SELECT ?patient_name  ?gender ?bg ?age ?address ?ID
                WHERE { 
                  ?patient a hs:OP_Patient.
                  ?patient hs:pat_id ?ID.
                  ?patient hs:pat_name ?patient_name.
                  ?patient hs:pat_gender ?gender.
                  ?patient hs:pat_bloodgroup ?bg.
                  ?patient hs:pat_address ?address.

                  ?patient hs:pat_age ?age.
        
                   }";
                $result = sparql_query( $sparql ); 
                return $result;
                }
            }
#TO get doctors list

public function getdoctors($doctorType){

        #Dermatologist
        if($doctorType=="Dermatology"){
        $sparql = "SELECT ?name ?designation ?time ?officenumber 
        WHERE { 
          ?doctor a hs:Dermatologist.
          
          ?doctor hs:name ?name.
          ?doctor hs:designation ?designation.
          ?doctor hs:doc_timining ?time.
          ?doctor hs:office_number ?officenumber

        }";
        $result = sparql_query( $sparql ); 
        
        return $result;
        }

        if($doctorType=="ENT"){
            $sparql = "SELECT ?name ?designation ?time ?officenumber 
            WHERE { 
              ?doctor a hs:ENT.
              
              ?doctor hs:name ?name.
              ?doctor hs:designation ?designation.
              ?doctor hs:doc_timining ?time.
              ?doctor hs:office_number ?officenumber
    
            }";
            $result = sparql_query( $sparql ); 
            
            return $result;
            }

            if($doctorType=="Gastroenterology"){
                $sparql = "SELECT ?name ?designation ?time ?officenumber 
                WHERE { 
                  ?doctor a hs:Gastroenterologist.
                  
                  ?doctor hs:name ?name.
                  ?doctor hs:designation ?designation.
                  ?doctor hs:doc_timining ?time.
                  ?doctor hs:office_number ?officenumber
        
                }";
                $result = sparql_query( $sparql ); 
                
                return $result;
                }

                if($doctorType=="Nephrology"){
                    $sparql = "SELECT ?name ?designation ?time ?officenumber 
                    WHERE { 
                      ?doctor a hs:Nephrologist.
                      
                      ?doctor hs:name ?name.
                      ?doctor hs:designation ?designation.
                      ?doctor hs:doc_timining ?time.
                      ?doctor hs:office_number ?officenumber
            
                    }";
                    $result = sparql_query( $sparql ); 
                    
                    return $result;
                    }
                
                    
                if($doctorType=="Neurology"){
                    $sparql = "SELECT ?name ?designation ?time ?officenumber 
                    WHERE { 
                      ?doctor a hs:Neurologist.
                      
                      ?doctor hs:name ?name.
                      ?doctor hs:designation ?designation.
                      ?doctor hs:doc_timining ?time.
                      ?doctor hs:office_number ?officenumber
            
                    }";
                    $result = sparql_query( $sparql ); 
                    
                    return $result;
                    }

                    if($doctorType=="Gynaecology"){
                        $sparql = "SELECT ?name ?designation ?time ?officenumber 
                        WHERE { 
                          ?doctor a hs:Gynaecologist.
                          
                          ?doctor hs:name ?name.
                          ?doctor hs:designation ?designation.
                          ?doctor hs:doc_timining ?time.
                          ?doctor hs:office_number ?officenumber
                
                        }";
                        $result = sparql_query( $sparql ); 
                        
                        return $result;
                        }
    }

    #TO get nurse list
public function getnurses(){

    #Nurse
    $sparql = "SELECT ?name ?officenumber ?doctorName 
      WHERE { 
      ?nurse a hs:nurses.
      ?nurse hs:name ?name.
      ?nurse hs:office_number ?officenumber.
  OPTIONAL{  ?nurse hs:reports_to ?doctor.
    ?doctor hs:name ?doctorName}
    }";
    $result = sparql_query( $sparql ); 
  
    return $result;
    }

    #to get patientlist using dropdown

    public function getDoctorPaitents($doctor){

      
      $sparql = "SELECT  DISTINCT ?patient_name ?ID ?gender ?bg ?age ?address
      WHERE { 
        ?doctors a ?hospital.
    ?hospital rdfs:subClassOf* hs:Doctors.
    
      ?doctors hs:name ?name.
      ?doctors hs:treats ?patient.
        
        ?patient hs:pat_name ?patient_name.
        ?patient hs:pat_id ?ID.
        ?patient hs:pat_gender ?gender.
        ?patient hs:pat_bloodgroup ?bg.

        ?patient hs:pat_age ?age.
        ?patient hs:pat_address ?address.
filter(str(?name)='$doctor')

         }";
      $result = sparql_query( $sparql ); 
    
      return $result;
      }
   
 #TO get otherstaff list
public function getotherstaffs($otherstaffType){

  #Accountant
  if($otherstaffType=="Accountant"){
  $sparql = "SELECT ?name ?officenumber 
  WHERE { 
    ?otherstaff a hs:Accountant.
    
    ?otherstaff hs:name ?name.
    ?otherstaff hs:office_number ?officenumber

  }";
  $result = sparql_query( $sparql ); 
  return $result;
  }

    #Ambulance driver
    if($otherstaffType=="AmbulanceDriver"){
      $sparql = "SELECT ?name ?officenumber 
      WHERE { 
        ?otherstaff a hs:Ambulance_driver.
        
        ?otherstaff hs:name ?name.
        ?otherstaff hs:office_number ?officenumber
    
      }";
      $result = sparql_query( $sparql ); 
      return $result;
      }

       #Cleanning staff
    if($otherstaffType=="Cleanning"){
      $sparql = "SELECT ?name ?officenumber 
      WHERE { 
        ?otherstaff a hs:Cleaning_staffs.
        
        ?otherstaff hs:name ?name.
        ?otherstaff hs:office_number ?officenumber
    
      }";
      $result = sparql_query( $sparql ); 
      return $result;
      }

       #Lab Attender
  if($otherstaffType=="labattender"){
    $sparql = "SELECT ?name ?officenumber 
    WHERE { 
      ?otherstaff a hs:labattender.
      
      ?otherstaff hs:name ?name.
      ?otherstaff hs:office_number ?officenumber
  
    }";
    $result = sparql_query( $sparql ); 
    return $result;
    }

     #Receptionist
  if($otherstaffType=="receptionist"){
    $sparql = "SELECT ?name ?officenumber 
    WHERE { 
      ?otherstaff a hs:receptionist.
      
      ?otherstaff hs:name ?name.
      ?otherstaff hs:office_number ?officenumber
  
    }";
    $result = sparql_query( $sparql ); 
    return $result;
    }

     #Security
  if($otherstaffType=="security"){
    $sparql = "SELECT ?name ?officenumber 
    WHERE { 
      ?otherstaff a hs:security.
      
      ?otherstaff hs:name ?name.
      ?otherstaff hs:office_number ?officenumber
  
    }";
    $result = sparql_query( $sparql ); 
    return $result;
    }
  }

  public function getAllDoctors(){
    $sparql = "SELECT ?name
    WHERE { 
{
      ?doctor a hs:Dermatologist.
      
      ?doctor hs:name ?name
}
union
{
?doctor a hs:ENT.
      
      ?doctor hs:name ?name
}
union
{
?doctor a hs:Gastroenterologist.
      
      ?doctor hs:name ?name
}
union
{
?doctor a hs:Gynaecologist.
      
      ?doctor hs:name ?name
}
union
{
?doctor a hs:Nephrologist.
      
      ?doctor hs:name ?name
}
  }";
    $result = sparql_query( $sparql ); 
    return $result;
  } 
  #to get department list

  public function getDept(){

      
    $sparql = "SELECT ?deptName
    WHERE { 
      ?dept a hs:Department.
?dept hs:dept_name ?deptName                     
}
";
    $result = sparql_query( $sparql ); 
  
    return $result;
    }



    public function getMedicine(){

      
      $sparql = "SELECT ?name ?price ?stock ?exp
      WHERE { 
        ?medicine a hs:Medicine_Name.
?medicine hs:med_price ?price.
  ?medicine hs:med_exp ?exp.
  ?medicine hs:med_stock ?stock.
    ?medicine hs:med_name ?name.




}";

      $result = sparql_query( $sparql ); 
    
      return $result;
      }


      public function getLab(){

      
        $sparql = "SELECT ?name ?price
        WHERE { 
          {
            ?lab a hs:scans.
            ?lab hs:test_price ?price.
            ?lab hs:test_name ?name
            }
            UNION
            {
              ?lab a hs:tests.
            ?lab hs:test_price ?price.
            ?lab hs:test_name ?name
              }
   }";
        $result = sparql_query( $sparql ); 
      
        return $result;
        }


public function sortMedicine($sort){

     
        $sparql = "SELECT ?name ?price ?stock ?exp
        WHERE { 
          ?medicine a hs:Medicine_Name.
  ?medicine hs:med_price ?price.
    ?medicine hs:med_exp ?exp.
    ?medicine hs:med_stock ?stock.
      ?medicine hs:med_name ?name.
   }order by $sort(?stock) ";
        $result = sparql_query( $sparql ); 
      
        return $result;
        }
      
      

  
}
?>