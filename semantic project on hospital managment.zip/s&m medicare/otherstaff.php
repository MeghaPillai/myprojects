<?php
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> Hospital management System </title>

    <link rel="shortcut icon" href="assets/images/fav.jpg">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawsom-all.min.css">
     <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
</head>

    <body>

    <!-- ################# Header Starts Here#######################--->
    
      <header id="menu-jk">
    
        <div id="nav-head" class="header-nav">
            <div class="container">
                <div class="row">
                    <div class="col-lg-2 col-md-3  col-sm-12" style="color:#000;font-weight:bold; font-size:42px; margin-top: 1% !important;">S&M Medicare
                       <a data-toggle="collapse" data-target="#menu" href="#menu" ><i class="fas d-block d-md-none small-menu fa-bars"></i></a>
                    </div>
                    <div id="menu" class="col-lg-8 col-md-9 d-none d-md-block nav-item">
                        <ul>
                            <li><a href="#">Home</a></li>
                            <li><a href="#services">Services</a></li>
                            
                            <li><a href="#contact_us">Contact Us</a></li>
                       
                        </ul>
                    </div>
                 
                </div>

            </div>
        </div>
    </header>

 <!-- ################# Otherstaffs search#######################--->

    <section id="logins" class="our-blog container-fluid">
        <div class="container">
        <div class="inner-title">

                <h2><b><u>Choose Otherstaffs</u></b></h2>
            </div>
            <div class="col-sm-12 blog-cont">
                <div class="row no-margin">
                    <div class="col-sm-4 blog-smk">
                        <div class="blog-single">

                                <img src="assets/images/patient.jpg" width="500" height="180" alt="">

                            <div class="blog-single-det">
                                <h6>Accountant</h6>
                                <a href="otherstaffDetails.php?otherstaffType=Accountant"   >
                                    <button class="btn btn-success btn-sm">Click Here</button>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4 blog-smk">
                        <div class="blog-single">

                                <img src="assets\images\Discharged.jpg" width="500" height="180" alt="">

                            <div class="blog-single-det">
                                <h6>Ambulance Driver</h6>
                                <a href="otherStaffDetails.php?otherstaffType=AmbulanceDriver"   >
                                    <button class="btn btn-success btn-sm">Click Here</button>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-4 blog-smk">
                        <div class="blog-single">

                                <img src="assets\images\op.jpg"  width="500" height="180" alt="">

                            <div class="blog-single-det">
                                <h6>Cleaning Staffs</h6>
                    
                                <a href="otherstaffDetails.php?otherstaffType=Cleaning"   >
                                    <button class="btn btn-success btn-sm">Click Here</button>
                                </a>
                            </div>
                        </div>
                    </div>
                    
                     
                    <div class="col-sm-4 blog-smk">
                        <div class="blog-single">

                                <img src="assets\images\op.jpg"  width="500" height="180" alt="">

                            <div class="blog-single-det">
                                <h6>Lab Attender</h6>
                    
                                <a href="otherstaffDetails.php?otherstaffType=labattender"   >
                                    <button class="btn btn-success btn-sm">Click Here</button>
                                </a>
                            </div>
                        </div>
                    </div>

                     
                    <div class="col-sm-4 blog-smk">
                        <div class="blog-single">

                                <img src="assets\images\op.jpg"  width="500" height="180" alt="">

                            <div class="blog-single-det">
                                <h6>Receptionist</h6>
                    
                                <a href="otherstaffsDetails.php?otherstaffType=receptionist"   >
                                    <button class="btn btn-success btn-sm">Click Here</button>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4 blog-smk">
                        <div class="blog-single">

                                <img src="assets\images\op.jpg"  width="500" height="180" alt="">

                            <div class="blog-single-det">
                                <h6>Security</h6>
                    
                                <a href="otherstaffsDetails.php?otherstaffType=security"   >
                                    <button class="btn btn-success btn-sm">Click Here</button>
                                </a>
                            </div>
                        </div>
                    </div>

                    
                    
                    
              ==

                    </html>