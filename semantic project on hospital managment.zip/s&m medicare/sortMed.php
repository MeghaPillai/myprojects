<!doctype html>
<?php
include( "functions.php" );
 
$obj =  new Functions();
$sort = $_GET["sort"];
$result = $obj->sortMedicine($sort); 
?>
<html lang="en">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> Hospital management System </title>

    <link rel="shortcut icon" href="assets/images/fav.jpg">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawsom-all.min.css">
     <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" type="text/css" href="assets/css/style.css" />
</head>
<body>

<!-- ################# Header Starts Here#######################--->

  <header id="menu-jk">

    <div id="nav-head" class="header-nav">
        <div class="container">
            <div class="row">
                <div class="col-lg-2 col-md-3  col-sm-12" style="color:#000;font-weight:bold; font-size:42px; margin-top: 1% !important;">S&M Medicare
                   <a data-toggle="collapse" data-target="#menu" href="#menu" ><i class="fas d-block d-md-none small-menu fa-bars"></i></a>
                </div>
                <div id="menu" class="col-lg-8 col-md-9 d-none d-md-block nav-item">
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#services">Services</a></li>
                        
                        <li><a href="#contact_us">Contact Us</a></li>
                   
                    </ul>
                </div>
             
            </div>

        </div>
    </div>
</header>

<!-- ################# nurse search#######################--->

<section id="logins" class="our-blog container-fluid">


        <div class="container">
        <div class="inner-title">

                <h2 style="color:Tomato;"><b><u> MEDICINES</u></b></h2>
            </div>
            <div class="dropdown text-center">
  <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    SORT
  </button>
  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">

  <a class="dropdown-item" href="sortMed.php?sort=DESC">STOCK (High to Low)</a>
  <a class="dropdown-item" href="sortMed.php?sort=ASC">STOCK (Low to High)</a>
</div><br>
    
    <table class="table table-bordered">
    <tr>
    <th>MEDICINE NAME</th>
    <th>PRICE</th>

    <th>STOCK</th>

    <th>EXPIRY DATE</th>

    
    </tr>
        <?php
		while( $row = sparql_fetch_array( $result ) )
		{
		?>           <tr>
                  <td class="card-text"><?php echo $row["name"]; ?></td>
                  <td class="card-text"><?php echo $row["price"]; ?></td>
                  <td class="card-text"><?php echo $row["stock"]; ?></td>
                  <td class="card-text"><?php echo $row["exp"]; ?></td>
                  


                  </tr>
            <?php } ?>

        
  </body>
</html>